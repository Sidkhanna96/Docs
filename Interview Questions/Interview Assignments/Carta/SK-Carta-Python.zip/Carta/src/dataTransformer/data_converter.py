import csv
from collections import defaultdict
from datetime import datetime
from typing import List, Dict, Any
from utils.custom_enum import FieldNames, OperationPriority

"Assign list of transactions for each employee and then sort it according to date"
def employee_transaction(transactions_ledger: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    transactions = defaultdict(list)

    for tl in transactions_ledger:
        key = (tl[FieldNames.EMPLOYEE_ID.value], tl[FieldNames.AWARD_ID.value])
        transactions[key].append(tl)

    for key in transactions:
        transactions[key].sort(key=lambda item: (item[FieldNames.DATE.value], OperationPriority[item[FieldNames.OPERATION.value]].value))

    return transactions

"Parse a CSV file provieded"
def parse_file(file_name: str) -> List[Dict[str, Any]]:
    transactions_orm = [] 
    field_names = [field.value for field in FieldNames]
    
    try:
        with open(file_name, newline='') as csvfile:
            reader = csv.DictReader(csvfile, field_names)
            for row in reader:
                row[FieldNames.DATE.value] = datetime.strptime(row[FieldNames.DATE.value], "%Y-%m-%d")
                row[FieldNames.QUANTITY.value] = float(row[FieldNames.QUANTITY.value])
                transactions_orm.append(row)
    except FileNotFoundError:
        print(f"Error: The file '{file_name}' does not exist.")
    except csv.Error:
        print(f"Error: The file '{file_name}' is not a valid CSV file.")
    except Exception as e:
        print(f"Error: {e}")

    return transactions_orm