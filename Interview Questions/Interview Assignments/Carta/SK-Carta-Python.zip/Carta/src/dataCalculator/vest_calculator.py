from decimal import Decimal, getcontext, ROUND_DOWN
from typing import List, Dict, Any
from utils.custom_enum import FieldNames, OperationPriority
import datetime

"""
truncate the float value
"""
def truncate(num: Decimal, precision: int) -> Decimal:
    factor = Decimal(10) ** -precision
    return num.quantize(factor, rounding=ROUND_DOWN)

"""
Calculate the total amount vested by the employee
"""
def vest_calculator(employee_ledger: Dict[str, List[Dict[str, Any]]], date_on_before: datetime, precision: int) -> List[List[Any]]:
    res = []

    for employee in employee_ledger:
        total = Decimal(0)
        for emp_transaction in employee_ledger[employee]:
            try:
                if emp_transaction[FieldNames.DATE.value] > date_on_before:
                    break
                else:
                    quantity = truncate(Decimal(emp_transaction[FieldNames.QUANTITY.value]), precision)
                    
                    if emp_transaction[FieldNames.OPERATION.value] == OperationPriority.VEST.name:
                        total += quantity
                    if emp_transaction[FieldNames.OPERATION.value] == OperationPriority.CANCEL.name and total >= quantity:
                        total -= quantity

                    total = truncate(total, precision)  # Truncate to the specified precision
            except KeyError as e:
                print(f"Error: Missing field {e} in transaction {emp_transaction}")
            except Exception as e:
                print(f"Error: {e}")

        res.append([
            emp_transaction.get(FieldNames.EMPLOYEE_ID.value, "Unknown"),
            emp_transaction.get(FieldNames.EMPLOYEE_NAME.value, "Unknown"),
            emp_transaction.get(FieldNames.AWARD_ID.value, "Unknown"),
            float(total)
        ])

    return res