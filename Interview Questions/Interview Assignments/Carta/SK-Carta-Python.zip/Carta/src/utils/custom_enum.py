from enum import Enum

"""
Enum of all the fields in CSV
"""
class FieldNames(Enum):
    OPERATION = "OPERATION"
    EMPLOYEE_ID = "EMPLOYEE_ID"
    EMPLOYEE_NAME = "EMPLOYEE_NAME"
    AWARD_ID = "AWARD_ID"
    DATE = "DATE"
    QUANTITY = "QUANTITY"

"""
Priority of sorting based on operation
"""
class OperationPriority(Enum):
    VEST = 1
    CANCEL = 2
    # Add other operations as needed