import sys
from datetime import datetime
from src.dataTransformer.data_converter import parse_file, employee_transaction
from src.dataCalculator.vest_calculator import vest_calculator

def main(arguments):
    if len(arguments) < 2:
        raise Exception("Error: not enough arguments provided")
    
    try:
        """
        Fetch all the arguments
        """
        file_name = arguments[1]
        date_on_before = datetime.strptime(arguments[2], "%Y-%m-%d")
        precision = int(arguments[3]) if len(arguments) >= 4 else 0

        """
        Fetch data from csv file and convert it
        """
        transactions_ledger = parse_file(file_name)
        employee_ledger = employee_transaction(transactions_ledger)

        """
        Calculate the total transaction
        """
        employee_total_vest = vest_calculator(employee_ledger, date_on_before, precision)

        for emp_transaction in employee_total_vest:
            print(", ".join(map(str, emp_transaction)))

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main(sys.argv)