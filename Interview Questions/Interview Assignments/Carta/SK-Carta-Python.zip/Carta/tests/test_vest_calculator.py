import pytest
from decimal import Decimal
from datetime import datetime
from src.dataCalculator.vest_calculator import vest_calculator
from utils.custom_enum import FieldNames, OperationPriority

# Mock data for testing
mock_employee_ledger = {
    ("E001", "ISO-001"): [
        {"OPERATION": "VEST", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": datetime(2020, 1, 1), "QUANTITY": 1000.0},
        {"OPERATION": "CANCEL", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": datetime(2020, 6, 1), "QUANTITY": 500.0},
    ],
    ("E002", "ISO-002"): [
        {"OPERATION": "VEST", "EMPLOYEE_ID": "E002", "EMPLOYEE_NAME": "Bob Johnson", "AWARD_ID": "ISO-002", "DATE": datetime(2020, 2, 15), "QUANTITY": 1500.0},
    ]
}

mock_employee_ledger_with_missing_field = {
    ("E001", "ISO-001"): [
        {"OPERATION": "VEST", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": datetime(2020, 1, 1)},
    ]
}

mock_employee_ledger_with_invalid_data = {
    ("E001", "ISO-001"): [
        {"OPERATION": "VEST", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": datetime(2020, 1, 1), "QUANTITY": "invalid"},
    ]
}

def test_vest_calculator():
    date_on_before = datetime(2020, 12, 31)
    precision = 2
    result = vest_calculator(mock_employee_ledger, date_on_before, precision)
    expected_result = [
        ["E001", "Alice Smith", "ISO-001", 500.0],
        ["E002", "Bob Johnson", "ISO-002", 1500.0]
    ]
    assert result == expected_result

def test_vest_calculator_with_no_transactions():
    empty_employee_ledger = {}
    date_on_before = datetime(2020, 12, 31)
    precision = 2
    result = vest_calculator(empty_employee_ledger, date_on_before, precision)
    expected_result = []
    assert result == expected_result

def test_vest_calculator_with_future_date():
    date_on_before = datetime(2019, 12, 31)
    precision = 2
    result = vest_calculator(mock_employee_ledger, date_on_before, precision)
    expected_result = [
        ["E001", "Alice Smith", "ISO-001", 0.0],
        ["E002", "Bob Johnson", "ISO-002", 0.0]
    ]
    assert result == expected_result

def test_vest_calculator_with_missing_field():
    date_on_before = datetime(2020, 12, 31)
    precision = 2
    result = vest_calculator(mock_employee_ledger_with_missing_field, date_on_before, precision)
    expected_result = [
        ["E001", "Alice Smith", "ISO-001", 0.0]
    ]
    assert result == expected_result

def test_vest_calculator_with_invalid_data():
    date_on_before = datetime(2020, 12, 31)
    precision = 2
    result = vest_calculator(mock_employee_ledger_with_invalid_data, date_on_before, precision)
    expected_result = [
        ["E001", "Alice Smith", "ISO-001", 0.0]
    ]
    assert result == expected_result

