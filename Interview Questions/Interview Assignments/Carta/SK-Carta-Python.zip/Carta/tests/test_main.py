import pytest
from unittest.mock import patch
from datetime import datetime
import sys
from src.main import main

# Mock data for testing
mock_transactions_ledger = [
    {"OPERATION": "VEST", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": "2020-01-01", "QUANTITY": 1000},
    {"OPERATION": "CANCEL", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": "2020-06-01", "QUANTITY": 500},
]

mock_employee_ledger = {
    ("E001", "ISO-001"): [
        {"OPERATION": "VEST", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": "2020-01-01", "QUANTITY": 1000},
        {"OPERATION": "CANCEL", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": "2020-06-01", "QUANTITY": 500},
    ]
}

mock_employee_total_vest = [
    ["E001", "Alice Smith", "ISO-001", 500.0]
]

@patch('src.main.parse_file', return_value = mock_transactions_ledger)  # Corrected target
@patch('src.main.employee_transaction', return_value = mock_employee_ledger)  # Corrected target
@patch('src.main.vest_calculator', return_value = mock_employee_total_vest)  # Corrected target
@patch('builtins.print')
def test_main_happy_path(mock_print, mock_vest_calculator, mock_employee_transaction, mock_parse_file):
    test_args = ["main.py", "mock_file.csv", "2020-12-31", "2"]
    main(test_args)
    
    mock_parse_file.assert_called_with("mock_file.csv")
    mock_employee_transaction.assert_called_once_with(mock_transactions_ledger)
    mock_vest_calculator.assert_called_once_with(mock_employee_ledger, datetime.strptime("2020-12-31", "%Y-%m-%d"), 2)
    mock_print.assert_any_call("E001, Alice Smith, ISO-001, 500.0")

@patch('src.main.parse_file', side_effect=Exception("File error"))  # Corrected target
@patch('builtins.print')
def test_main_exception(mock_print, mock_parse_file):
    test_args = ["main.py", "mock_file.csv", "2020-12-31", "2"]
    main(test_args)

    mock_parse_file.assert_called_once_with("mock_file.csv")
    mock_print.assert_any_call("Error: File error")

@patch('builtins.print')
@patch('sys.argv', new=["main.py"])  # Mock sys.argv directly
def test_main_not_enough_arguments(mock_print):
    with pytest.raises(Exception, match="Error: not enough arguments provided"):
        main(sys.argv)

    # Ensure no print statements are called
    mock_print.assert_not_called()