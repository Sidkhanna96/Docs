from unittest.mock import patch, mock_open
from datetime import datetime
from src.dataTransformer.data_converter import parse_file, employee_transaction
import csv

# Mock data for testing
mock_csv_data = """VEST,E001,Alice Smith,ISO-001,2020-01-01,1000
CANCEL,E001,Alice Smith,ISO-001,2020-06-01,500
"""

mock_empty_csv_data = ""  # Empty CSV file

mock_transactions_ledger = [
    {"OPERATION": "VEST", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": "2020-01-01", "QUANTITY": 1000.0},
    {"OPERATION": "CANCEL", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": "2020-06-01", "QUANTITY": 500.0},
]

mock_employee_ledger = {
    ("E001", "ISO-001"): [
        {"OPERATION": "VEST", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": "2020-01-01", "QUANTITY": 1000.0},
        {"OPERATION": "CANCEL", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": "2020-06-01", "QUANTITY": 500.0},
    ]
}

# Test parse_file with valid data
@patch("builtins.open", new_callable=mock_open, read_data=mock_csv_data)
def test_parse_file(mock_file):
    result = parse_file("mock_file.csv")
    assert result == [
        {"OPERATION": "VEST", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": datetime(2020, 1, 1), "QUANTITY": 1000.0},
        {"OPERATION": "CANCEL", "EMPLOYEE_ID": "E001", "EMPLOYEE_NAME": "Alice Smith", "AWARD_ID": "ISO-001", "DATE": datetime(2020, 6, 1), "QUANTITY": 500.0},
    ]

# Test employee_transaction with valid data
def test_employee_transaction():
    result = employee_transaction(mock_transactions_ledger)
    assert result == mock_employee_ledger

# Test parse_file with a file not found
@patch("builtins.open", side_effect=FileNotFoundError)
def test_parse_file_file_not_found(mock_file):
    result = parse_file("mock_file.csv")
    assert result == []

# Test parse_file with invalid CSV data
@patch("builtins.open", new_callable=mock_open, read_data="invalid,data")
@patch("csv.DictReader", side_effect=csv.Error)
def test_parse_file_csv_error(mock_csv_reader, mock_file):
    result = parse_file("mock_file.csv")
    assert result == []

# Test parse_file with a generic exception
@patch("builtins.open", new_callable=mock_open, read_data=mock_csv_data)
@patch("csv.DictReader", side_effect=Exception("Generic error"))
def test_parse_file_generic_exception(mock_csv_reader, mock_file):
    result = parse_file("mock_file.csv")
    assert result == []

# Test parse_file with an empty CSV file
@patch("builtins.open", new_callable=mock_open, read_data=mock_empty_csv_data)
def test_parse_file_empty_file(mock_file):
    result = parse_file("mock_file.csv")
    assert result == []
