# Running

- Need to install python3
- this file does not use any modules that are not included with python3 but use pip3 to install any libraries if missing

- Below is a basic command to run the application

```
python3 main.py ../mockTests/stage_1.csv 2021-02-01 1
```

- For unit tests, install pytest through pip3

```
pip3 install pytest
PYTHONPATH=src pytest --cov=src tests/
```
