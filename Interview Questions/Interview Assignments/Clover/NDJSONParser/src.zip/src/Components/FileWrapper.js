const fs = require("fs");
const util = require("util");

// Promisify - so can use async await/promise - instead of utilizing the inbuilt callback function
const readdir = util.promisify(fs.readdir);

class FileWrapper {
  async fetchFiles(path) {
    // Fetch all files in specs folder
    const dirents = await readdir(path, { withFileTypes: true });
    const files = dirents
      .filter(
        // only select files and filter out hidden files through regex
        (dirent) => dirent.isFile() && !/(^|\/)\.[^\/\.]/g.test(dirent.name)
      )
      .map((dirent) => dirent.name);

    return files;
  }
}

module.exports = { FileWrapper };
